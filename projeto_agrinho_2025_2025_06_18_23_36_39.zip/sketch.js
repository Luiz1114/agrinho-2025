let harvestRate = 1; // How fast produce is generated
let transportationEfficiency = 1; // How fast produce moves
let cityDemand = 1; // How fast city consumes
let produce = []; // Array to store individual produce items
let opportunities = 0; // Counter for opportunities

function setup() {
  createCanvas(800, 600);
  // Create sliders for interaction
  let harvestSlider = createSlider(0.1, 5, harvestRate, 0.1);
  harvestSlider.position(20, 20);
  harvestSlider.input(() => harvestRate = harvestSlider.value());
  let harvestLabel = createElement('p', 'Taxa de Colheita');
  harvestLabel.position(160, 5);

  let transportSlider = createSlider(0.1, 5, transportationEfficiency, 0.1);
  transportSlider.position(20, 50);
  transportSlider.input(() => transportationEfficiency = transportSlider.value());
  let transportLabel = createElement('p', 'Eficiência de Transporte');
  transportLabel.position(160, 35);

  let demandSlider = createSlider(0.1, 5, cityDemand, 0.1);
  demandSlider.position(20, 80);
  demandSlider.input(() => cityDemand = demandSlider.value());
  let demandLabel = createElement('p', 'Demanda da Cidade');
  demandLabel.position(160, 65);
}

function draw() {
  background(135, 206, 235); // Light blue sky

  // --- Rural Area (Left Half) ---
  fill(100, 150, 50); // Green for fields
  rect(0, height / 2, width / 2, height / 2); // Ground
  fill(50, 100, 20); // Darker green for texture
  noStroke();
  for (let i = 0; i < 50; i++) {
    ellipse(random(width / 2), random(height / 2, height), 5, 5);
  }

  // Generate produce
  if (frameCount % int(60 / harvestRate) == 0) { // Adjust generation speed
    produce.push(new Produce(random(width / 2), random(height / 2, height)));
  }

  // --- City Area (Right Half) ---
  fill(150); // Grey for city
  rect(width / 2, 0, width / 2, height);
  // Simple buildings
  fill(100);
  rect(width * 0.6, height - 100, 50, 100);
  rect(width * 0.7, height - 150, 60, 150);
  rect(width * 0.8, height - 80, 40, 80);

  // --- Produce Logic ---
  for (let i = produce.length - 1; i >= 0; i--) {
    let p = produce[i];
    p.display();
    p.move(transportationEfficiency);

    // If produce reaches the city
    if (p.x > width / 2 && p.y < height) {
      // "Consume" produce and create opportunities based on city demand
      if (random(1) < cityDemand * 0.01) { // Probability of consumption
        opportunities++;
        produce.splice(i, 1); // Remove consumed produce
      }
    }

    // If produce goes off screen (consider as waste or lost)
    if (p.x > width || p.y < 0) {
        produce.splice(i, 1);
    }
  }

  // --- Display Opportunities ---
  fill(0);
  textSize(24);
  textAlign(RIGHT);
  text("Oportunidades: " + opportunities, width - 20, 40);

  // Optional: Display information about remaining produce
  textSize(16);
  textAlign(LEFT);
  text("Produtos em Trânsito: " + produce.length, 20, height - 20);
}

// Class for a single produce item
class Produce {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.size = 10;
    this.speed = 2;
    this.targetX = width * 0.75; // Roughly center of city
    this.targetY = height * 0.75;
  }

  display() {
    fill(255, 200, 0); // Yellow for produce (e.g., corn, wheat)
    ellipse(this.x, this.y, this.size, this.size);
  }

  move(efficiency) {
    // Move towards the city
    let angle = atan2(this.targetY - this.y, this.targetX - this.x);
    this.x += cos(angle) * this.speed * efficiency;
    this.y += sin(angle) * this.speed * efficiency;
  }
}